"""Thin wrapper around ChromaDB + Ollama embeddings."""
import requests
import chromadb

import config


def embed(texts, is_query=False):
    """Embed a list of strings with the local Ollama embedding model.
    nomic-embed-text works best with these task prefixes."""
    prefix = "search_query: " if is_query else "search_document: "
    if "nomic" not in config.EMBED_MODEL:
        prefix = ""
    resp = requests.post(
        f"{config.OLLAMA_URL}/api/embed",
        json={"model": config.EMBED_MODEL, "input": [prefix + t for t in texts]},
        timeout=300,
    )
    resp.raise_for_status()
    return resp.json()["embeddings"]


def get_collection(reset=False):
    client = chromadb.PersistentClient(path=config.CHROMA_DIR)
    if reset:
        try:
            client.delete_collection(config.COLLECTION_NAME)
        except Exception:
            pass
    return client.get_or_create_collection(
        name=config.COLLECTION_NAME, metadata={"hnsw:space": "cosine"}
    )
