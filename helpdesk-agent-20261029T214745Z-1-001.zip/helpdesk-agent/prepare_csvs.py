"""Convert the raw department course sheets in data/csv/ into the three clean files
the tools use: timetable.csv, courses.csv, faculty.csv.

Raw sheets have different column names/layouts per department; this script
recognises the common header variants, merges everything, derives the course
level from the course code (CSL7650 -> 700), maps slot letters to lecture timings
using the slot-system sheet, and takes instructor emails from faculty_emails.csv
(names not found there get a DUMMY email).

Run:  python prepare_csvs.py          (re-run whenever you add/replace a sheet)
"""
import csv
import hashlib
import re

import pandas as pd

import config

OUTPUTS = {"timetable.csv", "courses.csv", "faculty.csv"}
EMAILS_FILE = "faculty_emails.csv"          # columns: Faculty Name, Email ID

# department name per file-name prefix (edit if you add sheets)
DEPARTMENTS = {
    "aero": "Aerospace Engineering",
    "aide": "School of Artificial Intelligence and Data Science (AIDE)",
    "bsbe": "Bioscience and Bioengineering",
    "cet": "Centre for Education Technology",
    "chemical": "Chemical Engineering",
    "cse": "Computer Science and Engineering",
    "ece": "Electronics and Communication Engineering",
    "ee": "Electrical Engineering",
    "math": "Mathematics",
    "mt": "Materials Engineering",
    "sme": "School of Management and Entrepreneurship",
    "sola": "School of Liberal Arts (Humanities and Social Sciences)",
    "hss": "School of Liberal Arts (Humanities and Social Sciences)",
    "me": "Mechanical Engineering",
    "civil": "Civil and Infrastructure Engineering",
    "physics": "Physics",
    "chemistry": "Chemistry",
}

# used only when several files are identical copies (department taken from course codes)
CODE_PREFIX = {
    "MA": "Mathematics", "CS": "Computer Science and Engineering",
    "EE": "Electrical Engineering", "EC": "Electronics and Communication Engineering",
    "ME": "Mechanical Engineering", "MT": "Materials Engineering",
    "BB": "Bioscience and Bioengineering", "ED": "Centre for Education Technology",
    "MS": "School of Management and Entrepreneurship", "CY": "Chemistry", "PH": "Physics",
    "CH": "Chemical Engineering", "CE": "Civil and Infrastructure Engineering",
    "LA": "School of Liberal Arts (Humanities and Social Sciences)",
    "AI": "School of Artificial Intelligence and Data Science (AIDE)",
}

# header synonyms -> standard field (exact match first, then 'contains')
FIELDS = {
    "course_code": ["course code", "subject code", "code"],
    "course_name": ["course name", "name of the course", "subject name", "course title"],
    "credits": ["credits", "credit"],
    "ltp": ["l-t-p", "[l-t-p]", "ltp", "l-t-p structure"],
    "instructor": ["instructor name", "instructor", "instructor(s)", "name of faculty",
                   "faculty", "faculty name"],
    "co_instructors": ["co-instructors", "co-instructor", "co instructors"],
    "slot": ["slot"],
    "category": ["category (pc/pe/ic)", "course category", "course type", "category"],
    "remarks": ["remarks", "remark", "programme", "offered for", "program", "batch", "comment"],
}

CATEGORY_NAMES = {"PC": "Programme Core", "PE": "Programme Elective", "IC": "Institute Core",
                  "OE": "Open Elective", "IE": "Institute Elective", "HSS": "HSS Elective",
                  "DE": "Department Elective", "DC": "Department Core", "SE": "Science Elective",
                  "PR": "Project", "NG": "Non-graded"}


def clean(s):
    return re.sub(r"\s+", " ", str(s or "")).strip()


def department_for(path):
    key = path.stem.lower().split()[0]
    return DEPARTMENTS.get(key, path.stem.split(" - ")[0].strip())


def find_header(rows):
    for i, row in enumerate(rows[:10]):
        low = [clean(c).lower() for c in row]
        if any("code" in c for c in low) and any(("name" in c or "title" in c) for c in low):
            return i
    return None


def map_columns(header):
    low = [clean(c).lower() for c in header]
    mapping = {}
    for field, names in FIELDS.items():
        idx = next((i for i, c in enumerate(low)
                    if c in names and i not in mapping.values()), None)
        if idx is None:
            idx = next((i for i, c in enumerate(low) if c and i not in mapping.values()
                        and any(n in c for n in names)
                        and not (field == "course_code" and ("name" in c or "title" in c))), None)
        if idx is not None:
            mapping[field] = idx
    return mapping


def level_of(code):
    m = re.search(r"[A-Za-z]+\s*(\d)", code)
    return f"{m.group(1)}00" if m else ""


def category_of(cat, remarks):
    raw = clean(cat)
    toks = re.findall(r"[A-Za-z]+", raw.upper())
    # electives first, so 'SE/PE' or 'DC/OE' count as electives
    for tok in ["OE", "HSS", "PE", "DE", "IE", "SE", "PC", "DC", "IC", "PR", "NG"]:
        if tok in toks:
            name = CATEGORY_NAMES[tok]
            return name if raw.upper() == tok else f"{name} ({raw})"
    if raw:
        return raw
    r = f" {remarks.lower()} "
    for key, name in [("open elective", "Open Elective"), ("hss", "HSS Elective"),
                      (" pe", "Programme Elective"), ("elec", "Programme Elective"),
                      ("thesis", "Thesis/Project"), ("project", "Thesis/Project"),
                      ("core", "Core"), (" pc", "Programme Core")]:
        if key in r:
            return name
    return ""


# ------------------------------------------------------------------ emails
def norm_name(name):
    name = re.sub(r"\b(dr|prof|mr|ms|mrs|hod)\b\.?", " ", clean(name), flags=re.I)
    return " ".join(re.findall(r"[a-z]+", name.lower()))


def load_emails(path):
    if not path.exists():
        return {}
    df = pd.read_csv(path, dtype=str).fillna("")
    name_col = next(c for c in df.columns if "name" in c.lower())
    mail_col = next(c for c in df.columns if "mail" in c.lower())
    return {norm_name(n): clean(m) for n, m in zip(df[name_col], df[mail_col]) if clean(m)}


def find_email(name, emails):
    """Exact name, then first+last name, then a unique first-name or surname match."""
    n = norm_name(name)
    if not n:
        return ""
    if n in emails:
        return emails[n]
    parts = n.split()
    for full, mail in emails.items():
        fp = full.split()
        if len(parts) > 1 and fp and fp[0] == parts[0] and fp[-1] == parts[-1]:
            return mail
    # A lone first name ('Dr. Krunal') is not matched: it could be a different person.
    return ""


def dummy_email(name):
    parts = norm_name(name).split()
    return (".".join(parts[:2]) + "@dummy.iitj.ac.in") if parts else ""


def split_names(text):
    text = re.sub(r"\(.*?\)", ",", clean(text))      # '(1.5)', '(Coordinated by ...)'
    parts = re.split(r",|/|&|\band\b", text)
    return [clean(p) for p in parts if clean(p) and clean(p) not in {"-", "TBD"}
            and norm_name(p)]


# ------------------------------------------------------------------ slots
def parse_slot_grid(path):
    """slot letter -> 'Mon 9-9:50; Tue ...' from the 'slot system' sheet."""
    rows = list(csv.reader(open(path, encoding="utf-8-sig")))
    days_row = next((r for r in rows if "Mon" in [clean(c) for c in r]), None)
    if not days_row:
        return {}
    day_cols = {i: clean(c) for i, c in enumerate(days_row) if clean(c) in
                {"Mon", "Tue", "Wed", "Thu", "Fri"}}
    slots = {}
    for r in rows:
        t = clean(r[0]) if r else ""
        if not re.match(r"^\d", t):
            continue
        t = t.replace("–", "-").replace(" ", "")
        for col, day in day_cols.items():
            for c in (col, col + 1):          # theory slot, then lab slot column
                if c < len(r):
                    s = clean(r[c])
                    if re.fullmatch(r"[A-Z]\d{0,2}", s):
                        slots.setdefault(s, []).append(f"{day} {t}")
    return {k: "; ".join(v) for k, v in slots.items()}


def timings_for(slot, slot_map):
    tokens = re.split(r"[,/+ ]+", re.sub(r"\(.*?\)", "", slot))
    return "; ".join(slot_map[t] for t in tokens if t in slot_map)


# ------------------------------------------------------------------ main
def main():
    raw_files = [p for p in sorted(config.CSV_DIR.glob("*.csv"))
                 if p.name not in OUTPUTS and p.name != EMAILS_FILE]
    slot_file = next((p for p in raw_files if "slot" in p.name.lower()), None)
    slot_map = parse_slot_grid(slot_file) if slot_file else {}
    emails = load_emails(config.CSV_DIR / EMAILS_FILE)
    print(f"Slot grid: {len(slot_map)} slots | faculty emails: {len(emails)} names")

    hashes = {p: hashlib.md5(p.read_bytes()).hexdigest() for p in raw_files if p != slot_file}
    dup_hashes = {h for h in hashes.values() if list(hashes.values()).count(h) > 1}
    seen_hash, records = {}, []
    for path in raw_files:
        if path == slot_file:
            continue
        digest = hashes[path]
        if digest in seen_hash:
            print(f"  ! '{path.name}' is IDENTICAL to '{seen_hash[digest]}' - skipped "
                  f"(probably the wrong sheet was downloaded)")
            continue
        seen_hash[digest] = path.name

        rows = list(csv.reader(open(path, encoding="utf-8-sig")))
        h = find_header(rows)
        if h is None:
            print(f"  ! '{path.name}': could not find a header row - skipped")
            continue
        cols = map_columns(rows[h])
        dept = department_for(path)
        if digest in dup_hashes and "course_code" in cols:
            prefixes = [re.sub(r"[^A-Z]", "", clean(r[cols["course_code"]]).upper())[:2]
                        for r in rows[h + 1:] if cols["course_code"] < len(r)]
            prefixes = [p for p in prefixes if p]
            if prefixes:
                dept = CODE_PREFIX.get(max(set(prefixes), key=prefixes.count), dept)

        section, n = "", 0
        for row in rows[h + 1:]:
            def get(f):
                return clean(row[cols[f]]) if f in cols and cols[f] < len(row) else ""
            name, code = get("course_name"), get("course_code").replace(" ", "")
            if not name:
                filled = [clean(c) for c in row if clean(c)]
                if len(filled) == 1:            # a section title like 'M.Tech DCS Executive'
                    section = filled[0]
                continue
            remarks = get("remarks") or section
            slot = get("slot")
            timings = timings_for(slot, slot_map)
            records.append({
                "course_code": code, "course_name": name, "department": dept,
                "level": level_of(code), "category": category_of(get("category"), remarks),
                "credits": re.sub(r"[^\d.]", "", get("credits").split("(")[0]),
                "ltp": get("ltp").strip("[]()"), "slot": slot,
                "lecture_timings": timings or ("" if not slot else "see slot system / remarks"),
                "instructors": split_names(get("instructor")) + split_names(get("co_instructors")),
                "programme": remarks, "semester": "2026-27", "source_file": path.name,
            })
            n += 1
        print(f"  + {path.name}: {n} courses  ({dept})")

    df = pd.DataFrame(records)
    if df.empty:
        raise SystemExit("No courses found.")
    df["instructor"] = df["instructors"].map(", ".join)

    df[["course_code", "course_name", "department", "level", "category", "credits", "ltp",
        "instructor", "programme", "semester", "source_file"]].to_csv(config.COURSES_CSV,
                                                                     index=False)
    df[["course_code", "course_name", "slot", "lecture_timings", "instructor", "department",
        "programme", "semester"]].assign(venue="").to_csv(config.TIMETABLE_CSV, index=False)

    fac, real, missing = [], 0, set()
    for r in records:
        for i, nm in enumerate(r["instructors"]):
            mail = find_email(nm, emails)
            if mail:
                real += 1
            else:
                missing.add(nm)
            fac.append({"course_code": r["course_code"], "course_name": r["course_name"],
                        "instructor": nm, "role": "Instructor" if i == 0 else "Co-instructor",
                        "email": mail or dummy_email(nm),
                        "email_source": "faculty list" if mail else "DUMMY",
                        "department": r["department"]})
    pd.DataFrame(fac).drop_duplicates().to_csv(config.FACULTY_CSV, index=False)

    print(f"\nWrote {len(df)} courses -> courses.csv, timetable.csv")
    print(f"faculty.csv: {len(fac)} instructor rows, {real} with real email, "
          f"{len(fac) - real} DUMMY ({len(missing)} names not in {EMAILS_FILE})")


if __name__ == "__main__":
    main()
