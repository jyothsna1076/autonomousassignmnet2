"""Agent definitions (Google ADK + Ollama via LiteLLM).

build_single_agent()  -> one agent that has every tool   (base version)
build_multi_agent()   -> orchestrator that transfers to policy / schedule / email agents
"""
import os

from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm
from google.genai import types

import config
from tools import (search_documents, lookup_timetable, list_courses,
                   find_courses_by_instructor,
                   get_instructor_contact, draft_email, log_unanswered)

REFUSAL = ("I'm sorry, I don't know the answer to that. "
           "I have logged your question so the academic office can help you.")

SCOPE = """You are the Academic Helpdesk of the institute. You ONLY handle:
academic programs, course contents, curriculum and credit requirements, academic rules
and regulations (attendance, grading, exams, registration), office orders, the time table
and course slots, courses floated this semester, which courses an instructor teaches,
instructor contact details, and drafting
emails to instructors (sick leave, makeup exam).
Anything else (dining, hostel food, transport, directions, sports, general knowledge,
opinions) is OUT OF SCOPE."""

GROUNDING = f"""STRICT RULES:
1. Never answer from your own knowledge. Every fact must come from a tool result.
2. End every answer with a line 'Source: ' followed by the citation(s) exactly as given by
   the tool, e.g. Source: [academic_regulations.pdf, page 12].
3. If the question is out of scope, OR the tool returns found=False / nothing relevant,
   call log_unanswered(question, reason) and then reply exactly:
   "{REFUSAL}"
4. Do not guess, do not add information that is not in the tool result.
5. State the rule exactly as the passage states it. Do not add your own conclusions or
   conditions (e.g. do not say something is required "to be eligible for exams" unless
   the passage says exactly that).
6. Keep answers short and direct. Give only the final answer, no reasoning steps."""


def _model(model_name=None):
    name = model_name or config.LLM_MODEL
    if "qwen3" in name:
        # Switch off Qwen3's 'thinking' mode: it is slow (~2 min/answer) and its
        # reasoning text leaks into the answer. LiteLLM sends this to Ollama as think=false.
        return LiteLlm(model=name, reasoning_effort="none")
    return LiteLlm(model=name)


def _prefix(model_name):
    # Extra safety for older Ollama versions that ignore think=false.
    return "/no_think\n" if "qwen3" in (model_name or config.LLM_MODEL) else ""


def _gen_config():
    return types.GenerateContentConfig(
        temperature=float(os.environ.get("HELPDESK_TEMPERATURE", "0.3")))


# ------------------------------------------------------------------ single agent
def build_single_agent(model_name=None):
    instruction = _prefix(model_name) + SCOPE + """

Which tool to use:
- rules, regulations, attendance, exams, grading, curriculum, credits, programs,
  course contents, office orders  -> search_documents
  (amendment/circular documents from 2024 are newer than the 2019 regulations; if they
  disagree, the amendment wins - say so and cite it)
- slot / timing / venue of a course                              -> lookup_timetable
- how many / which courses or electives are floated              -> list_courses
- which courses an instructor/professor teaches                  -> find_courses_by_instructor
- instructor name or email                                       -> get_instructor_contact
- write an email to an instructor -> get_instructor_contact, then draft_email
  (say clearly that it is a draft and has not been sent)

""" + GROUNDING
    return LlmAgent(
        name="academic_helpdesk",
        model=_model(model_name),
        description="Answers academic questions using institute documents.",
        instruction=instruction,
        tools=[search_documents, lookup_timetable, list_courses, find_courses_by_instructor,
               get_instructor_contact, draft_email, log_unanswered],
        generate_content_config=_gen_config(),
    )


# ------------------------------------------------------------------ multi agent
def build_multi_agent(model_name=None):
    p = _prefix(model_name)

    policy_agent = LlmAgent(
        name="policy_agent",
        model=_model(model_name),
        description=("Answers questions about academic rules and regulations, attendance, "
                     "exams, grading, academic programs, curriculum, credit requirements, "
                     "course contents and office orders."),
        instruction=p + SCOPE + """

You are the POLICY agent. Always call search_documents first (you may call it again
with a rephrased query once if the first results are not relevant). Answer only from
the returned passages.
Circulars / amendments (file names containing 'ammendment', 'amendment' or 'circular',
dated July 2024) are NEWER than the Academic Regulations (2019). If they disagree, the
amendment wins: give the amendment's rule, cite it, and mention it replaced the old rule.

""" + GROUNDING,
        tools=[search_documents, log_unanswered],
        # Specialists answer and stop. Disallowing transfers makes ADK hand every NEW
        # message back to the orchestrator (otherwise, in a chat, the next question goes
        # straight to whichever specialist answered last, which may lack the right tools).
        disallow_transfer_to_parent=True,
        disallow_transfer_to_peers=True,
        generate_content_config=_gen_config(),
    )

    schedule_agent = LlmAgent(
        name="schedule_agent",
        model=_model(model_name),
        description=("Answers questions about the time table: slot, timings and venue of a "
                     "course, how many / which courses or electives are floated by a "
                     "department this semester, and which courses an instructor teaches."),
        instruction=p + SCOPE + """

You are the SCHEDULE agent.
- Slot / timing / venue of a course -> lookup_timetable
- Counting or listing courses/electives floated -> list_courses (use its 'count' value
  exactly; do not count yourself)
- Which courses an instructor / professor / Dr. X teaches -> find_courses_by_instructor
  (list every course it returns with its code and slot)

""" + GROUNDING,
        tools=[lookup_timetable, list_courses, find_courses_by_instructor, log_unanswered],
        # Specialists answer and stop. Disallowing transfers makes ADK hand every NEW
        # message back to the orchestrator (otherwise, in a chat, the next question goes
        # straight to whichever specialist answered last, which may lack the right tools).
        disallow_transfer_to_parent=True,
        disallow_transfer_to_peers=True,
        generate_content_config=_gen_config(),
    )

    email_agent = LlmAgent(
        name="email_agent",
        model=_model(model_name),
        description=("Finds a course instructor's contact details and drafts emails to "
                     "instructors, e.g. sick-leave or makeup-exam requests."),
        instruction=p + SCOPE + """

You are the EMAIL agent.
1. Call get_instructor_contact with the course code or name.
2. Write a short, polite, formal email. Use placeholders [Your Name], [Roll Number],
   [Dates] for any details the student did not give.
3. Call draft_email(to_email, subject, body) to save it.
4. Show the student the draft and state clearly: "This is a draft and has NOT been sent."
   If a tool result says email_verified=False or recipient_verified=False, also say:
   "The instructor's email address could not be verified - please confirm it before sending."
If only the instructor's contact was asked, just answer with it (no draft).

""" + GROUNDING,
        tools=[get_instructor_contact, draft_email, log_unanswered],
        # Specialists answer and stop. Disallowing transfers makes ADK hand every NEW
        # message back to the orchestrator (otherwise, in a chat, the next question goes
        # straight to whichever specialist answered last, which may lack the right tools).
        disallow_transfer_to_parent=True,
        disallow_transfer_to_peers=True,
        generate_content_config=_gen_config(),
    )

    orchestrator = LlmAgent(
        name="helpdesk_orchestrator",
        model=_model(model_name),
        description="Front desk that routes student questions to the right specialist.",
        instruction=p + SCOPE + f"""

You are the ORCHESTRATOR. You do not answer academic questions yourself.
Transfer the question to exactly one specialist:
- policy_agent   : rules, regulations, attendance, exams, curriculum, credits, programs,
                   course contents, office orders
- schedule_agent : slots, time table, timings, venue, number/list of courses or electives,
                   which courses an instructor/professor teaches
- email_agent    : instructor email/contact, drafting emails (leave, makeup exam)
If the question is OUT OF SCOPE, do not transfer: call log_unanswered(question,
"out of scope") and reply exactly: "{REFUSAL}"
""",
        tools=[log_unanswered],
        sub_agents=[policy_agent, schedule_agent, email_agent],
        generate_content_config=_gen_config(),
    )
    return orchestrator
