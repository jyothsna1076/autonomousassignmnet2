"""Central configuration. Every setting can be overridden with an environment variable,
so the same code runs on a laptop and in Google Colab without edits."""
import os
from pathlib import Path

# Project root = the folder this file lives in (override with HELPDESK_DIR)
BASE_DIR = Path(os.environ.get("HELPDESK_DIR", Path(__file__).resolve().parent))

DOCS_DIR = BASE_DIR / "data" / "docs"          # PDFs / DOCX / TXT / MD go here
CSV_DIR = BASE_DIR / "data" / "csv"            # timetable.csv, courses.csv, faculty.csv
LOG_DIR = BASE_DIR / "logs"
DRAFTS_DIR = BASE_DIR / "drafts"
RESULTS_DIR = BASE_DIR / "results"

TIMETABLE_CSV = CSV_DIR / "timetable.csv"
COURSES_CSV = CSV_DIR / "courses.csv"
FACULTY_CSV = CSV_DIR / "faculty.csv"
UNANSWERED_LOG = LOG_DIR / "unanswered_questions.csv"

# Vector store location. In Colab keep it on the local disk (/content), it is faster
# and avoids SQLite locking problems on Google Drive. Re-running ingest takes ~1-2 min.
_default_chroma = "/content/chroma_db" if Path("/content").exists() else str(BASE_DIR / "chroma_db")
CHROMA_DIR = os.environ.get("CHROMA_DIR", _default_chroma)
COLLECTION_NAME = "academic_docs"

# Ollama
OLLAMA_URL = os.environ.get("OLLAMA_API_BASE", "http://localhost:11434")
os.environ.setdefault("OLLAMA_API_BASE", OLLAMA_URL)   # LiteLLM reads this
EMBED_MODEL = os.environ.get("EMBED_MODEL", "nomic-embed-text")

# Chat model used by ADK through LiteLLM. Swap to compare, e.g.
#   HELPDESK_MODEL=ollama_chat/llama3.1:8b
LLM_MODEL = os.environ.get("HELPDESK_MODEL", "ollama_chat/qwen3:8b")

# Retrieval settings
CHUNK_SIZE = 900        # characters per chunk
CHUNK_OVERLAP = 150
TOP_K = 4
# Cosine distance above this = "not relevant enough" (0 = identical, 2 = opposite).
# Tune after looking at a few searches; 0.55-0.65 works well for nomic-embed-text.
MAX_DISTANCE = float(os.environ.get("MAX_DISTANCE", "0.6"))

# File-name keywords that mark newer amendments/circulars vs. the older regulations.
# search_documents labels passages with this so the model applies the newer rule.
AMENDMENT_KEYWORDS = ["ammendment", "amendment", "circular"]
OLD_REGULATION_KEYWORDS = ["academic_regulations", "regulation"]

for d in (DOCS_DIR, CSV_DIR, LOG_DIR, DRAFTS_DIR, RESULTS_DIR):
    d.mkdir(parents=True, exist_ok=True)
