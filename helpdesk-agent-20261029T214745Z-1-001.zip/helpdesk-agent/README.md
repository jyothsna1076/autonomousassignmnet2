# Academic Helpdesk Agent — multi-agent RAG with Google ADK + Ollama

A local helpdesk that answers questions about academic programs, course contents, rules and
regulations and the time table, drafts emails to instructors (sick leave / makeup exam),
cites the document every answer comes from, refuses out-of-scope questions and logs them
for a human.

## Architecture

```
                    student question
                           |
                 helpdesk_orchestrator  --(out of scope)-->  log_unanswered + "I don't know"
            transfer /       |        \ transfer
        policy_agent   schedule_agent   email_agent
             |            |      |          |        \
   search_documents  lookup_  list_   get_instructor_  draft_email
      (ChromaDB)     timetable courses   contact        (saved, not sent)
                     (timetable.csv) (courses.csv) (faculty.csv)
```

* LLM: `qwen3:8b` (or `llama3.1:8b`) served by Ollama, called from ADK through LiteLLM
* Embeddings: `nomic-embed-text` via Ollama
* Vector store: ChromaDB (cosine), chunks carry `source` + `page` metadata for citations
* Single-agent baseline: one agent with all six tools (`--mode single`)

## Files

| File | Purpose |
|---|---|
| `config.py` | Paths, model names, retrieval settings (all overridable by env vars) |
| `vector_store.py` | Ollama embedding call + ChromaDB collection |
| `prepare_csvs.py` | Merges the raw department sheets into the 3 lookup CSVs |
| `ingest.py` | Reads `data/docs`, chunks, embeds, stores in ChromaDB |
| `tools.py` | The 6 tools: `search_documents`, `lookup_timetable`, `list_courses`, `get_instructor_contact`, `draft_email`, `log_unanswered` |
| `agents.py` | Single agent and multi-agent (orchestrator + 3 specialists) |
| `helpdesk.py` | `Helpdesk.ask()` helper + interactive terminal chat |
| `evaluate.py` | Runs `eval/questions.csv` N times and computes the metrics |
| `Helpdesk_Colab.ipynb` | Runs everything on Google Colab (T4 GPU) |
| `data/docs/` | **Your 20–30 documents** (PDF, DOCX, TXT, MD) |
| `data/csv/` | **Your** `timetable.csv`, `courses.csv`, `faculty.csv` |
| `logs/unanswered_questions.csv` | Questions referred to a human |
| `drafts/` | Generated email drafts |
| `results/` | Evaluation outputs |

## 1. Collect the documents

Put 20–30 real files in `data/docs/`. Suggested set (from the institute website / LMS /
academic office notices):

1. UG academic regulations (B.Tech rules: attendance, grading, CGPA, exams, makeup, credit limits)
2. B.Tech curriculum / program structure (total credits, open elective & HSS credits)
3. Curriculum of your own branch (course list per semester)
4. Academic calendar for the current semester (add/drop, minor/major exam dates)
5. Course registration notice / guidelines
6. Time table PDF for the current semester
7. List of courses / electives floated this semester (each department if available)
8. 3–6 recent office orders / circulars from the academic section
9. Course descriptions / syllabus PDFs for a few courses (e.g. Autonomous Systems)
10. Leave rules / medical leave policy, makeup exam policy, grade-change policy
11. PG regulations, minor/honours rules, any FAQ the academic office has published

**Name files clearly** (e.g. `ug_regulations.pdf`, `btech_curriculum.pdf`,
`academic_calendar_2026_27.pdf`) — the names appear in citations and in `expected_source`.

Replace personal data (phone numbers, roll numbers, personal emails) with dummy values.
If a PDF is a scan (ingest prints "no text extracted"), copy its text into a `.txt` file
with the same name instead.

## 2. Course sheets → the three lookup CSVs

Put the department course sheets (exported from Google Sheets as CSV) and the
slot-system sheet in `data/csv/`, then run `python prepare_csvs.py`. It merges them into
`courses.csv`, `timetable.csv` and `faculty.csv`, derives the course level from the code,
fills lecture timings from the slot grid, creates DUMMY instructor emails, and warns about
sheets that are identical copies of each other. The raw sheets are also indexed by
`ingest.py`, so their notes are searchable.

### Manual format (if you prefer to write the files yourself)

The CSVs in `data/csv/` contain EXAMPLE rows only. Replace them with real data from the
time table and course list. Keep the column names exactly:

* `timetable.csv`: `course_code, course_name, slot, lecture_timings, venue, semester`
* `courses.csv`: `course_code, course_name, department, level, category, credits, semester`
  * `level` = 100/200/300/400/500/600/700… ; `category` e.g. Core, Department Elective,
    Open Elective, HSS Elective
* `faculty.csv`: `course_code, course_name, instructor, email, department`

Excel/Google Sheets: fill the sheet and use File → Download → CSV.

## 3a. Run on Google Colab (recommended if your laptop is slow)

1. Put this whole `helpdesk-agent` folder (with your docs and CSVs) in Google Drive:
   open drive.google.com → **New → Folder upload** → choose the `helpdesk-agent` folder.
   It must end up at `My Drive/helpdesk-agent/`.
2. Open `Helpdesk_Colab.ipynb` from Drive (double-click → *Open with Google Colaboratory*).
3. `Runtime → Change runtime type → T4 GPU`.
4. Run the cells in order. Cells 1–7 set up everything; 8–11 are demos; 12–15 evaluate.
5. To add documents later: drop them into `My Drive/helpdesk-agent/data/docs/` and re-run
   cell 7 (`ingest.py`).

Colab sessions reset, so re-run cells 1–7 each time you reconnect. Results, logs and
drafts are written to Drive and survive.

## 3b. Run on a laptop (16 GB RAM)

```bash
# 1. Install Ollama from https://ollama.com/download, then:
ollama pull qwen3:8b
ollama pull nomic-embed-text
# Give the model a larger context window (default is too small for tools + passages)
OLLAMA_CONTEXT_LENGTH=8192 ollama serve        # Windows: set the env var, then run ollama serve

# 2. Python 3.10+
pip install -r requirements.txt
python ingest.py                               # build the vector store
python helpdesk.py --mode multi                # chat in the terminal
python helpdesk.py --mode single               # single-agent baseline
```

## 4. Evaluation

`eval/questions.csv` has 26 questions (10 policy, 6 schedule, 4 email, 6 out-of-scope).
Columns:

* `category`: policy / schedule / email / out_of_scope
* `expected_agent`: which specialist should handle it (routing check)
* `expected_source`: part of the file name that must be cited, e.g. `regulations`, `timetable.csv`
* `expected_keywords`: `;`-separated words that a correct answer must contain, e.g. `75%`.
  **Fill these in from your documents.** Rows left empty are marked `?` and must be graded
  by hand in the `manual_correct` column of `results/raw_*.csv`.

```bash
python evaluate.py --mode multi --runs 3                                   # Qwen3 8B
python evaluate.py --mode multi --runs 3 --model ollama_chat/llama3.1:8b  # Llama 3.1 8B
python evaluate.py --mode single --runs 3                                  # baseline
```

Metrics (printed and appended to `results/model_comparison.csv`):

| Metric | Meaning |
|---|---|
| accuracy_% | in-scope answers containing all expected keywords |
| groundedness_% | in-scope answers citing the expected source |
| out_of_scope_refused_% | out-of-scope questions correctly refused |
| false_refusals_% | in-scope questions wrongly refused |
| routing_accuracy_% | orchestrator transferred to the expected specialist |
| questions_answer_changed | questions with different answer text across runs |
| questions_correctness_changed | questions that were right in one run and wrong in another |

`results/per_question_<tag>.csv` lists, per question, whether its answer, correctness or
routing changed across runs (needed for the report).

## Tuning tips

* `MAX_DISTANCE` in `config.py` controls how strict retrieval is. Too many false refusals →
  raise it (e.g. 0.7). Out-of-scope questions answered from irrelevant passages → lower it.
* `HELPDESK_TEMPERATURE` (default 0.3). Use 0 for more stable answers; keep >0 to study
  run-to-run variation.
* If an 8B model sometimes calls a tool that its agent does not have, `evaluate.py` records
  it as an ERROR row; mention these in the report as routing/tool-calling failures.

## Report outline

1. Problem and architecture (diagram above, agents and tools)
2. Data: list of documents and CSVs, chunking and embedding choices
3. Single-agent vs multi-agent design
4. Evaluation setup (questions, runs, metrics)
5. Results table per model (from `model_comparison.csv`)
6. Questions whose answers changed across runs, and why
7. Failure analysis: wrong routing, wrong citations, false refusals, hallucinations
8. Limitations and improvements
