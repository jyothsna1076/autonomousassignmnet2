"""Step 1 of the pipeline: read every document in data/docs, split it into chunks,
embed the chunks with Ollama and store them in ChromaDB with source + page metadata.

Run:  python ingest.py          (rebuilds the index from scratch)
"""
import re
import sys
from pathlib import Path

import config
from vector_store import embed, get_collection


def read_pdf(path):
    from pypdf import PdfReader
    reader = PdfReader(str(path))
    return [(i + 1, page.extract_text() or "") for i, page in enumerate(reader.pages)]


def read_docx(path):
    import docx
    text = "\n".join(p.text for p in docx.Document(str(path)).paragraphs)
    return [(1, text)]


def read_text(path):
    return [(1, Path(path).read_text(encoding="utf-8", errors="ignore"))]


def read_csv(path):
    """Spreadsheet -> text, one line per non-empty row, so its notes are searchable."""
    import csv
    lines = []
    for row in csv.reader(open(path, encoding="utf-8-sig", errors="ignore")):
        cells = [c.strip() for c in row if c and c.strip()]
        if cells:
            lines.append(" | ".join(cells))
    return [(1, "\n\n".join(lines))]


READERS = {".pdf": read_pdf, ".docx": read_docx, ".txt": read_text, ".md": read_text,
           ".csv": read_csv}
# served by the lookup tools instead of the vector store
CLEAN_CSVS = {"timetable.csv", "courses.csv", "faculty.csv", "faculty_emails.csv"}


def clean(text):
    text = text.replace("\x00", " ")
    # Some PDFs (e.g. web-exported circulars) put every word on its own line.
    # If lines are mostly single words, join everything back into normal sentences.
    lines = [l for l in text.splitlines() if l.strip()]
    if len(lines) > 30 and sum(len(l.split()) <= 1 for l in lines) / len(lines) > 0.7:
        text = re.sub(r"\s+", " ", text)
        text = re.sub(r"(?<=[.:;])\s+(?=[A-Z0-9>•-])", "\n\n", text)   # paragraph-ish breaks
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def chunk_text(text, size=config.CHUNK_SIZE, overlap=config.CHUNK_OVERLAP):
    """Split on paragraph boundaries where possible, falling back to a sliding window."""
    chunks, current = [], ""
    for para in re.split(r"\n\s*\n", text):
        para = para.strip()
        if not para:
            continue
        if len(current) + len(para) + 1 <= size:
            current = f"{current}\n{para}".strip()
            continue
        if current:
            chunks.append(current)
        while len(para) > size:                      # very long paragraph
            chunks.append(para[:size])
            para = para[size - overlap:]
        tail = current[-overlap:] if current else ""
        current = f"{tail}\n{para}".strip()
    if current:
        chunks.append(current)
    return chunks


def main():
    files = sorted(p for p in config.DOCS_DIR.rglob("*") if p.suffix.lower() in READERS)
    # also index the raw department sheets / slot system (not the 3 clean lookup files)
    files += sorted(p for p in config.CSV_DIR.glob("*.csv") if p.name not in CLEAN_CSVS)
    # skip exact duplicate files (same content saved under two names)
    import hashlib
    seen, unique = set(), []
    for p in files:
        h = hashlib.md5(p.read_bytes()).hexdigest()
        if h in seen:
            print(f"  ~ skipping duplicate file {p.name}")
            continue
        seen.add(h)
        unique.append(p)
    files = unique
    if not files:
        sys.exit(f"No documents found in {config.DOCS_DIR}. Add PDFs/DOCX/TXT there first.")

    collection = get_collection(reset=True)
    total = 0
    for path in files:
        try:
            pages = READERS[path.suffix.lower()](path)
        except Exception as e:
            print(f"  ! could not read {path.name}: {e}")
            continue

        ids, docs, metas = [], [], []
        for page_no, page_text in pages:
            for j, chunk in enumerate(chunk_text(clean(page_text))):
                if len(chunk) < 40:          # skip near-empty fragments
                    continue
                ids.append(f"{path.name}::p{page_no}::c{j}")
                docs.append(chunk)
                metas.append({"source": path.name, "page": page_no})

        if not docs:
            print(f"  ! {path.name}: no text extracted (scanned PDF? see README)")
            continue
        for start in range(0, len(docs), 32):          # embed in batches
            batch = slice(start, start + 32)
            collection.add(ids=ids[batch], documents=docs[batch],
                           metadatas=metas[batch], embeddings=embed(docs[batch]))
        total += len(docs)
        print(f"  + {path.name}: {len(docs)} chunks")

    print(f"\nIndexed {total} chunks from {len(files)} files into {config.CHROMA_DIR}")


if __name__ == "__main__":
    main()
