"""Evaluate the helpdesk on eval/questions.csv.

Runs every question N times (fresh session each time) and computes (all AUTOMATIC):
  accuracy_%               in-scope: answered (not refused, no error) and ALL expected
                           keywords present; refusal questions: correctly refused
  citation_present_%       in-scope answers that contain a [file] / [file, page n] citation
  groundedness_%           in-scope answers whose citations include the EXPECTED document.
                           This checks the right document was cited; it does NOT prove the
                           passage supports every claim (verify a sample by hand using the
                           'manual_correct' column of raw_<tag>.csv).
  out_of_scope_refused_%   non-academic questions refused
  not_in_data_refused_%    academic questions whose answer is not in the data, refused
  false_refusals_%         valid in-scope questions wrongly refused
  refusals_logged_%        refused questions that reached logs/unanswered_questions.csv
  errors                   runs that failed (model/connection error); never counted as
                           refusals or correct answers
  routing_accuracy_%       (multi-agent) the expected specialist agent handled the question
  consistency              questions whose answer / correctness / routing changed across runs
Questions with no expected_keywords are marked '?' and need manual grading.

Run:
  python evaluate.py --mode multi --runs 3
  python evaluate.py --mode multi --runs 3 --model ollama_chat/llama3.1:8b
  python evaluate.py --mode single --runs 3

Outputs (in results/):
  raw_<tag>.csv          every run of every question (add your manual grades here)
  per_question_<tag>.csv per-question scores + whether the answer changed across runs
  model_comparison.csv   one summary row appended per evaluation
"""
import argparse
import asyncio
import re
from datetime import datetime

import pandas as pd

import config
from helpdesk import Helpdesk, is_refusal

REFUSAL_CATEGORIES = ("out_of_scope", "not_in_data")
CITATION = re.compile(r"\[([^\[\]]*\.(?:pdf|csv|txt|docx|md)[^\[\]]*)\]", re.I)


def norm(s):
    return re.sub(r"\s+", " ", str(s).lower()).strip()


def citations(answer):
    """The bracketed citations in an answer, e.g. ['attendance ammendment.pdf, page 1']."""
    return [c.lower() for c in CITATION.findall(str(answer))]


def score(row, result):
    ans = norm(result["answer"])
    # Refusal status comes from the helpdesk's explicit status, not from tool calls.
    status = result.get("status") or ("refused" if is_refusal(result["answer"]) else "answered")
    refused, error = status == "refused", status == "error"
    expects_refusal = row["category"] in REFUSAL_CATEGORIES
    # keywords are case-insensitive regular expressions; ALL must match
    keywords = [k.strip().lower() for k in str(row.get("expected_keywords", "")).split(";")
                if k.strip()]
    source = str(row.get("expected_source", "")).strip().lower()
    cites = citations(result["answer"])

    if expects_refusal:
        accurate = refused
        cited = grounded = None                 # not applicable
    else:
        if not keywords:
            accurate = None                     # needs manual grading
        else:
            accurate = (status == "answered") and all(re.search(k, ans) for k in keywords)
        cited = bool(cites) if not error else False
        grounded = (any(source in c for c in cites) if source else None) if not error else False
    expected_agent = str(row.get("expected_agent", "")).strip()
    routed = (expected_agent in result["agents"]) if expected_agent else None
    return {"status": status, "refused": refused, "error": error,
            "logged": bool(result.get("logged")),
            "correct_refusal_behaviour": None if error else refused == expects_refusal,
            "accurate": accurate, "citation_present": cited, "grounded": grounded,
            "routed_correctly": routed}


def pct(series):
    s = series.dropna().astype(bool)
    return round(100 * s.mean(), 1) if len(s) else None


async def run(args):
    qs = pd.read_csv(args.questions, dtype=str).fillna("")
    hd = Helpdesk(args.mode, args.model)
    model = args.model or config.LLM_MODEL
    tag = args.tag or f"{args.mode}_{model.split('/')[-1].replace(':', '-')}"
    records = []

    for run_no in range(1, args.runs + 1):
        for _, row in qs.iterrows():
            try:
                result = await hd.ask(row["question"])
            except Exception as e:                       # keep going on model errors
                result = {"answer": f"ERROR: {e}", "agents": [], "tools": [], "seconds": 0,
                          "status": "error", "logged": False}
            rec = {"run": run_no, "id": row["id"], "category": row["category"],
                   "question": row["question"], "answer": result["answer"],
                   "agents": " -> ".join(result["agents"]),
                   "tools": ", ".join(result["tools"]), "seconds": result["seconds"]}
            rec.update(score(row, result))
            if args.mode == "single":
                rec["routed_correctly"] = None           # no routing in single-agent mode
            rec["manual_correct"] = ""                   # fill in by hand if you want
            records.append(rec)
            flag = ("ERR" if rec["error"] else "OK " if rec["accurate"]
                    else "?  " if rec["accurate"] is None else "X  ")
            print(f"[run {run_no}] {flag}{row['id']:>4} | {rec['agents'] or '-':45.45} | "
                  f"{row['question'][:60]}")

    raw = pd.DataFrame(records)
    raw.to_csv(config.RESULTS_DIR / f"raw_{tag}.csv", index=False)

    # ---- consistency across runs
    per_q = []
    for qid, g in raw.groupby("id", sort=False):
        per_q.append({
            "id": qid, "question": g["question"].iloc[0], "category": g["category"].iloc[0],
            "accuracy_%": pct(g["accurate"]), "grounded_%": pct(g["grounded"]),
            "errors": int(g["error"].sum()),
            "distinct_answers": g["answer"].map(norm).nunique(),
            "correctness_changed": g["accurate"].dropna().nunique() > 1,
            "routing_changed": g["agents"].nunique() > 1,
        })
    per_q = pd.DataFrame(per_q)
    per_q.to_csv(config.RESULTS_DIR / f"per_question_{tag}.csv", index=False)

    in_scope = raw[~raw["category"].isin(REFUSAL_CATEGORIES)]
    oos = raw[(raw["category"] == "out_of_scope") & ~raw["error"]]
    nid = raw[(raw["category"] == "not_in_data") & ~raw["error"]]
    refused_rows = raw[raw["refused"]]
    summary = {
        "timestamp": datetime.now().isoformat(timespec="seconds"), "tag": tag,
        "mode": args.mode, "model": model, "runs": args.runs, "questions": len(qs),
        "accuracy_%": pct(in_scope["accurate"]),
        "citation_present_%": pct(in_scope["citation_present"]),
        "groundedness_%": pct(in_scope["grounded"]),
        "out_of_scope_refused_%": pct(oos["refused"]),
        "not_in_data_refused_%": pct(nid["refused"]),
        "false_refusals_%": pct(in_scope.loc[~in_scope["error"], "refused"]),
        "refusals_logged_%": pct(refused_rows["logged"]),
        "errors": int(raw["error"].sum()),
        "routing_accuracy_%": pct(raw["routed_correctly"]) if args.mode == "multi" else None,
        "questions_answer_changed": int((per_q["distinct_answers"] > 1).sum()),
        "questions_correctness_changed": int(per_q["correctness_changed"].sum()),
        "avg_seconds": round(raw["seconds"].mean(), 1),
    }
    comp = config.RESULTS_DIR / "model_comparison.csv"
    new = pd.DataFrame([summary])
    if comp.exists():                     # columns may differ from older runs: merge safely
        new = pd.concat([pd.read_csv(comp), new], ignore_index=True)
    new.to_csv(comp, index=False)

    print("\n================ SUMMARY ================")
    for k, v in summary.items():
        print(f"{k:32} {v}")
    changed = per_q[per_q["correctness_changed"] | per_q["routing_changed"]]
    if len(changed):
        print("\nQuestions whose correctness/routing changed across runs:")
        for _, r in changed.iterrows():
            print(f"  {r['id']}: {r['question']}")
    print(f"\nFiles saved in {config.RESULTS_DIR}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["single", "multi"], default="multi")
    ap.add_argument("--model", default=None)
    ap.add_argument("--runs", type=int, default=3)
    ap.add_argument("--questions", default=str(config.BASE_DIR / "eval" / "questions.csv"))
    ap.add_argument("--tag", default=None)
    asyncio.run(run(ap.parse_args()))
