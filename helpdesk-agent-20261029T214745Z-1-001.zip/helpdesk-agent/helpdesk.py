"""Run the helpdesk: an `ask()` helper (used by the notebook and evaluate.py)
and an interactive chat in the terminal.

Terminal:  python helpdesk.py --mode multi          (or --mode single)
           python helpdesk.py --mode multi --model ollama_chat/llama3.1:8b
Notebook:  from helpdesk import Helpdesk
           hd = Helpdesk("multi");  r = await hd.ask("What is the slot for Autonomous Systems?")
"""
import argparse
import asyncio
import re
import time
import logging
import uuid
import warnings

warnings.filterwarnings("ignore", message=r".*EXPERIMENTAL.*")   # harmless ADK notice
logging.getLogger("google_adk").setLevel(logging.ERROR)           # hides context-cache tip
import litellm
litellm.suppress_debug_info = True                                # hides 'Provider List' noise

from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from agents import REFUSAL, build_multi_agent, build_single_agent
from tools import log_unanswered

APP = "academic_helpdesk"
# First-person refusal phrases only, so an answer that merely mentions e.g. "cannot
# register" is not mistaken for a refusal.
REFUSAL_PATTERN = re.compile(r"\bi (don'?t|do not) know\b|logged your question|"
                             r"\bi (cannot|can'?t|am not able to) answer\b", re.I)
UNVERIFIED_NOTE = ("The instructor's email address could not be verified - please confirm "
                   "it before sending.")


def _clean(text):
    return re.sub(r"<think>.*?</think>", "", text or "", flags=re.S).strip()


def is_refusal(answer):
    return bool(REFUSAL_PATTERN.search(answer or ""))


class Helpdesk:
    def __init__(self, mode="multi", model=None):
        agent = build_multi_agent(model) if mode == "multi" else build_single_agent(model)
        self.sessions = InMemorySessionService()
        self.runner = Runner(agent=agent, app_name=APP, session_service=self.sessions)
        self.user = "student"

    async def new_session(self):
        sid = str(uuid.uuid4())
        await self.sessions.create_session(app_name=APP, user_id=self.user, session_id=sid)
        return sid

    async def ask(self, question, session_id=None):
        """Ask one question. A fresh session is used unless session_id is given.

        Returns dict(answer, agents, tools, seconds, status, logged):
          status  'answered' | 'refused' | 'error'  (an error is never counted as a refusal)
          logged  True if the question was written to the unanswered-questions log
          raw_answer  the model's own final text before any clean-up (for debugging)
        """
        sid = session_id or await self.new_session()
        msg = types.Content(role="user", parts=[types.Part(text=question)])
        answer, agents, tools, draft, verified = "", [], [], "", True
        logged, error = False, ""
        t0 = time.time()
        try:
            async for event in self.runner.run_async(user_id=self.user, session_id=sid,
                                                     new_message=msg):
                if event.author and event.author != "user" and event.author not in agents:
                    agents.append(event.author)
                for call in event.get_function_calls() or []:
                    tools.append(call.name)
                for resp in event.get_function_responses() or []:
                    data = resp.response or {}
                    if isinstance(data.get("result"), dict):
                        data = data["result"]
                    if resp.name == "draft_email":
                        draft = data.get("draft", "") or draft
                        verified = data.get("recipient_verified", True)
                    if resp.name == "log_unanswered" and data.get("logged"):
                        logged = True
                if event.is_final_response() and event.content and event.content.parts:
                    text = "".join(p.text or "" for p in event.content.parts)
                    if text.strip():
                        answer = text
        except Exception as e:                       # model / connection failure
            error = f"{type(e).__name__}: {e}"
        answer = _clean(answer)
        raw_answer = answer                          # the model's own text, for debugging

        if draft and not error:
            # A draft was actually saved: this is a real answer, never a refusal, even if
            # the model's text contains a phrase like "I don't know the reason, so...".
            status = "answered"
            if "To:" not in answer:
                # The model did not show the draft: always show the saved draft.
                answer = (f"Here is your email draft:\n\n{draft.strip()}\n\n"
                          f"This is a draft and has NOT been sent.\n\nSource: [faculty.csv]")
            if not verified and UNVERIFIED_NOTE not in answer:
                answer = f"{answer}\n\n{UNVERIFIED_NOTE}"
        elif error or not answer:
            # An error is NOT a refusal. Still log it so a human sees the question.
            status = "error"
            answer = f"ERROR: {error or 'the model returned no answer'}"
            if not logged:
                log_unanswered(question, "error - no answer produced")
                logged = True
                tools.append("log_unanswered(auto)")
        elif is_refusal(answer):
            status = "refused"
            # Guarantee every refused question reaches the human-review log, even when the
            # model forgets to call log_unanswered (8B models often do), and drop any
            # made-up 'Source:' line from the refusal.
            if not logged:
                log_unanswered(question, "refused - auto-logged by helpdesk")
                logged = True
                tools.append("log_unanswered(auto)")
            answer = REFUSAL
        else:
            status = "answered"
        return {"answer": answer, "agents": agents, "tools": tools,
                "seconds": round(time.time() - t0, 1), "status": status, "logged": logged,
                "raw_answer": raw_answer}


async def chat(mode, model):
    hd = Helpdesk(mode, model)
    sid = await hd.new_session()
    print(f"Academic Helpdesk ({mode}-agent). Type 'exit' to quit.\n")
    while True:
        q = input("You: ").strip()
        if q.lower() in {"exit", "quit"}:
            break
        if not q:
            continue
        try:
            r = await hd.ask(q, sid)
        except Exception as e:      # e.g. the model called a tool that doesn't exist
            print(f"\n[error] {e}\n")
            sid = await hd.new_session()
            continue
        print(f"\nHelpdesk: {r['answer']}")
        print(f"   (agents: {' -> '.join(r['agents'])} | tools: {r['tools']} | {r['seconds']}s)\n")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["single", "multi"], default="multi")
    ap.add_argument("--model", default=None, help="e.g. ollama_chat/llama3.1:8b")
    args = ap.parse_args()
    asyncio.run(chat(args.mode, args.model))
