"""Tools the agents can call. ADK turns each function into a tool automatically,
using the type hints and docstring, so keep the docstrings clear: the LLM reads them."""
import csv
import difflib
import re
from datetime import datetime

import pandas as pd

import config
from vector_store import embed, get_collection


# ----------------------------------------------------------------- helpers
def _norm_code(s):
    return re.sub(r"[^A-Z0-9]", "", str(s).upper())


def _load(path):
    if not path.exists():
        return None
    return pd.read_csv(path, dtype=str).fillna("")


def _match_course(df, course):
    """Find rows matching a course code (CSL7570 / csl 7570) or a course name (fuzzy)."""
    q = _norm_code(course)
    rows = df[df["course_code"].map(_norm_code) == q]
    if rows.empty:
        names = df["course_name"].str.lower()
        rows = df[names.str.contains(re.escape(course.lower().strip()), na=False)]
    if rows.empty:
        close = difflib.get_close_matches(course.lower(), names.tolist(), n=2, cutoff=0.6)
        rows = df[names.isin(close)]
    return rows


# ----------------------------------------------------------------- RAG tool
def search_documents(query: str) -> dict:
    """Search the official academic documents (rules and regulations, curriculum,
    credit requirements, attendance rules, exam rules, academic calendar, office orders)
    for passages relevant to the question.

    Args:
        query: The student's question or a short search phrase.

    Returns:
        A dict with 'results': a list of passages, each with 'citation' (document and page)
        and 'text'. If 'found' is False, nothing relevant exists in the documents.
    """
    collection = get_collection()
    if collection.count() == 0:
        return {"found": False, "message": "The document index is empty. Run ingest.py."}
    res = collection.query(query_embeddings=embed([query], is_query=True),
                           n_results=config.TOP_K)
    results = []
    for text, meta, dist in zip(res["documents"][0], res["metadatas"][0], res["distances"][0]):
        if dist <= config.MAX_DISTANCE:
            item = {"citation": f"[{meta['source']}, page {meta['page']}]",
                    "relevance": round(1 - dist, 3)}
            status = _document_status(meta["source"])
            if status:
                item["document_status"] = status
            item["text"] = text
            results.append(item)
    if not results:
        return {"found": False,
                "message": "No relevant passage found in the academic documents."}
    # amendments first, so the current rule is read before the old one
    results.sort(key=lambda r: not r.get("document_status", "").startswith("CURRENT"))
    return {"found": True, "results": results}


def _document_status(source):
    """Label amendments vs. the older regulations so the model applies the newer rule."""
    name = source.lower()
    if any(k in name for k in config.AMENDMENT_KEYWORDS):
        return ("CURRENT RULE (2024 amendment/circular). If this text quotes an 'Existing "
                "policy', that old policy is CANCELLED - only the 'Revised Policy' / new rule "
                "is in force.")
    if any(k in name for k in config.OLD_REGULATION_KEYWORDS):
        return ("OLDER REGULATIONS (2019). On topics covered by a 2024 amendment (attendance, "
                "minor/major exams and evaluation) this text is SUPERSEDED - do not use it "
                "for those topics.")
    return ""


# ----------------------------------------------------------------- CSV tools
def lookup_timetable(course: str) -> dict:
    """Look up the time-table slot, lecture timings and venue of a course.

    Args:
        course: A course code such as 'CSL7570' or a course name such as 'Autonomous Systems'.

    Returns:
        A dict with the matching time-table rows and the citation 'timetable.csv'.
    """
    df = _load(config.TIMETABLE_CSV)
    if df is None:
        return {"found": False, "message": "timetable.csv is missing."}
    rows = _match_course(df, course)
    if rows.empty:
        return {"found": False, "message": f"No course matching '{course}' in the time table."}
    return {"found": True, "citation": "[timetable.csv]", "rows": rows.to_dict("records")}


def list_courses(department: str = "", level: str = "", category: str = "") -> dict:
    """List and COUNT the courses floated this semester, filtered by department,
    level and/or category. Use this for 'how many electives / courses' questions.

    Args:
        department: Department name or part of it, e.g. 'Humanities', 'Computer Science'.
            Empty string = all departments.
        level: Course level, e.g. '400' or '700'. Empty string = all levels.
        category: e.g. 'Elective', 'Open Elective', 'Core'. Empty string = all categories.

    Returns:
        A dict with 'count' (number of matching courses), the list of courses and the citation.
    """
    df = _load(config.COURSES_CSV)
    if df is None:
        return {"found": False, "message": "courses.csv is missing."}
    m = pd.Series(True, index=df.index)
    if department:
        m &= df["department"].str.lower().str.contains(department.lower().strip(), regex=False)
    if level:
        lvl = re.sub(r"\D", "", level)[:1]          # '400', '400-level', '4xx' -> '4'
        m &= df["level"].str.strip().str.startswith(lvl)
    if category:
        m &= df["category"].str.lower().str.contains(category.lower().strip(), regex=False)
    rows = df[m]
    return {
        "count": int(len(rows)),
        "filters": {"department": department, "level": level, "category": category},
        "courses": rows[["course_code", "course_name", "department", "level",
                         "category", "credits"]].to_dict("records"),
        "citation": "[courses.csv]",
    }


def get_instructor_contact(course: str) -> dict:
    """Get the name and email ID of the instructor of a course.

    Args:
        course: A course code such as 'CSL7570' or a course name.

    Returns:
        A dict with instructor name(s), email(s) and the citation 'faculty.csv'.
    """
    df = _load(config.FACULTY_CSV)
    if df is None:
        return {"found": False, "message": "faculty.csv is missing."}
    rows = _match_course(df, course)
    if rows.empty:
        return {"found": False, "message": f"No instructor found for '{course}'."}
    records = rows.to_dict("records")
    for r in records:
        r["email_verified"] = _email_verified(r.get("email", ""), r.get("email_source", ""))
    result = {"found": True, "citation": "[faculty.csv]", "rows": records}
    if not all(r["email_verified"] for r in records):
        result["warning"] = ("Some email addresses are PLACEHOLDERS (email_verified=False): "
                             "the real address was not in the faculty email list. Tell the "
                             "student the address must be verified before sending.")
    return result


DUMMY_DOMAIN = "@dummy.iitj.ac.in"


def _email_verified(email, source=""):
    """An email is verified only if it came from the official faculty email list."""
    email = str(email).strip().lower()
    if not email or DUMMY_DOMAIN in email or str(source).upper() == "DUMMY":
        return False
    return True


def _recipient_verified(to_email):
    """Check a draft recipient against faculty.csv (must be a known, non-dummy address)."""
    df = _load(config.FACULTY_CSV)
    if df is None or "email" not in df.columns:
        return False
    hits = df[df["email"].str.strip().str.lower() == str(to_email).strip().lower()]
    if hits.empty:
        return False
    src = hits["email_source"].iloc[0] if "email_source" in hits.columns else ""
    return _email_verified(to_email, src)


def find_courses_by_instructor(instructor: str) -> dict:
    """Find which courses a given instructor / professor / faculty member is teaching
    this semester. Use this for questions like 'What does Dr. X teach?'.

    Args:
        instructor: The instructor's name, e.g. 'Gaurav Harit' or 'Dr. Sumit Kalra'.
            Titles like Dr./Prof. are ignored.

    Returns:
        A dict with the matching instructor name(s), their courses (code, name, slot,
        role) and the citation 'faculty.csv'.
    """
    df = _load(config.FACULTY_CSV)
    if df is None:
        return {"found": False, "message": "faculty.csv is missing."}
    query = _name_tokens(instructor)
    if not query:
        return {"found": False, "message": "Please give the instructor's name."}
    names = df["instructor"].map(_name_tokens)
    # every word the student typed must appear in the instructor's name
    rows = df[names.map(lambda n: all(q in n for q in query))]
    if rows.empty:
        return {"found": False, "message": f"No courses found for instructor '{instructor}'."}
    tt = _load(config.TIMETABLE_CSV)
    slots = dict(zip(tt["course_code"], tt["slot"])) if tt is not None else {}
    courses = [{"course_code": r["course_code"], "course_name": r["course_name"],
                "slot": slots.get(r["course_code"], ""), "role": r.get("role", ""),
                "instructor": r["instructor"]}
               for _, r in rows.drop_duplicates(["course_code", "instructor"]).iterrows()]
    matched = sorted(rows["instructor"].unique())
    result = {"found": True, "instructors_matched": matched, "count": len(courses),
              "courses": courses, "citation": "[faculty.csv]"}
    if len(matched) > 1:
        result["warning"] = (f"The name matches {len(matched)} different instructors: "
                             f"{', '.join(matched)}. List them separately or ask which one.")
    return result


def _name_tokens(name):
    name = re.sub(r"\b(dr|prof|professor|mr|ms|mrs|sir|madam)\b\.?", " ", str(name).lower())
    return [t for t in re.findall(r"[a-z]+", name) if len(t) > 1]


# ----------------------------------------------------------------- action tools
def draft_email(to_email: str, subject: str, body: str) -> dict:
    """Save an email DRAFT for the student to review. The email is NOT sent.

    Args:
        to_email: The instructor's email address (get it with get_instructor_contact first).
        subject: Email subject line.
        body: Full email text. Use placeholders like [Your Name], [Roll Number] for
            details the student has not given.

    Returns:
        A dict with the saved file path and the draft text.
    """
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    path = config.DRAFTS_DIR / f"draft_{stamp}.txt"
    verified = _recipient_verified(to_email)
    header = "" if verified else (
        "NOTE: RECIPIENT NOT VERIFIED - this address is a placeholder or is not in the "
        "official faculty email list. Confirm the instructor's real email before sending.\n")
    text = f"{header}To: {to_email}\nSubject: {subject}\n\n{body}\n"
    path.write_text(text, encoding="utf-8")
    result = {"saved": True, "status": "DRAFT - not sent", "recipient_verified": verified,
              "file": str(path.name), "draft": text}
    if not verified:
        result["warning"] = ("Recipient not verified. Tell the student this address must be "
                             "confirmed before sending.")
    return result


def log_unanswered(question: str, reason: str) -> dict:
    """Record a question the helpdesk cannot answer so a human can answer it later.
    Call this whenever the question is out of scope or the documents do not contain the answer.

    Args:
        question: The student's question, word for word.
        reason: Short reason, e.g. 'out of scope' or 'not found in documents'.

    Returns:
        A dict confirming the question was logged.
    """
    new = not config.UNANSWERED_LOG.exists()
    with open(config.UNANSWERED_LOG, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["timestamp", "question", "reason"])
        w.writerow([datetime.now().isoformat(timespec="seconds"), question, reason])
    return {"logged": True,
            "message": "Logged for a human to answer. Tell the student you do not know."}


ALL_TOOLS = [search_documents, lookup_timetable, list_courses, find_courses_by_instructor,
             get_instructor_contact, draft_email, log_unanswered]
